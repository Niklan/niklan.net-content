<?php

namespace Drupal\plugin_messages\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Аннотации для плагина PluginMessages.
 *
 * @Annotation
 */
class PluginMessages extends Plugin {

  /**
   * ID плагина.
   */
  public $id;

}
