#!/bin/bash

echo -n "Введите имя создаваемого хоста: "
read newHost

newPath="/home/nikita/domains/$newHost"
mkdir $newPath


#Производим запись в hosts
file="/etc/hosts"
b=$(cat $file)
newContent="127.0.0.1	${newHost}"$'\n'"127.0.0.1	www.${newHost}"$'\n'$b
sudo bash -c "echo '${newContent}' > $file"

#Добавляем сайт в sites-available и прописываем в него нужные директивы
sap=/etc/apache2/sites-available/$newHost.conf
sudo touch $sap
sudo chmod 777 $sap
directives="<VirtualHost *:80>
	ServerName ${newHost}
	ServerAlias ${newHost} www.${newHost}
	DocumentRoot /home/nikita/domains/${newHost}

	<Directory ${newPath:1}/>
		AllowOverride All
		Require all granted
	</Directory>
</VirtualHost>"
echo "$directives">$sap

#Включаем виртуальный хост
sudo a2ensite $newHost

#Перезапускаем сервер
sudo /etc/init.d/apache2 restart
