/**
 * @file
 * Just a placeholder file for the test.
 * @see ViewsCacheTest::testHeaderStorage
 */
