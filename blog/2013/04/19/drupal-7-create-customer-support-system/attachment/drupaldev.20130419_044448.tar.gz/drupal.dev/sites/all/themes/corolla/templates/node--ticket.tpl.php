<article class="node-<?php print $node->nid; ?> <?php print $classes; ?> clearfix"<?php print $attributes; ?>>

  <div class="ticket-wrapper">
    <div class="ticket-author">
      <?php
        print "<h3 class='username'>" . $name . "</h3>"; 
        if ($user_picture) {
          print $user_picture;
        }
        else {
          print "<img src='/sites/all/themes/drupalife_company/images/noavatar.png' alt=''>";
        }
       ?>

    </div>
    <div class='ticket-content'>
      <div class="ticket-info">
        <i>Текущие данные:</i><br/>
        <?php

          if (!empty($node->field_ticket_priority['und'][0]['taxonomy_term']->name)) {
            print "<strong>Приоритет:</strong> " . $node->field_ticket_priority['und'][0]['taxonomy_term']->name . "<br />";
          }
          if (!empty($node->field_ticket_department['und'][0]['taxonomy_term']->name)) {
            print "<strong>Департамент:</strong> " . $node->field_ticket_department['und'][0]['taxonomy_term']->name . "<br />";
          }
        ?>
      </div>
      <br />
      <?php
        print $node->body['und'][0]['safe_value'];
      ?>
    </div>
  </div>  

  <?php print render($content['comments']); ?>

</article><!-- /.node -->
